import ROOT
from ROOT import TFile, TCanvas
from plottingCode import plotROC, DrawHist

#Messy code because I didn't understand certain things during writing, will clean up later

#Define Names used in GeneralTauEfficiency
SignalVarNames = ["lPt", "lEta", "lE", "dxy", "dz", "relIso", "tauAgainstElectronMVA6Raw", "tauCombinedIsoDBRaw3Hits", "ptRel", "ptRatio"]
SignalVarHistNames = ["lpt", "leta", "lE", "dxy", "dz", "reliso", "tauAgainstElectronMVA6Raw", "tauCombinedIsoDBRaw3Hits", "ptRel", "ptRatio"]
SignalxHistNames = ["P_{T} [GeV]", "#eta", "E [GeV]", "d_{xy} [cm]", "d_{z} [cm]", "reliso", "tauAgainstElectronMVA6Raw", "tauCombinedIsoDBRaw3Hits", "ptRel", "ptRatio"]
BkgrVarNames = ["jetPt", "jetEta", "jetE", "jetCsvV2"]
BkgrVarHistNames = ["jetpt", "jeteta", "jetE", "jetCsvV2"]
BkgrxHistNames = ["jet p_{T} [GeV]", "jet #eta", "jet E [GeV]", "jetCsvV2"]
discriminatorNames = ["OldMVA", "NewMVA", "CutBased"]
WPNames = ["VLoose", "Loose", "Medium", "Tight", "VTight"]
WPNamesCutBased = ["VVLoose", "VLoose","Loose", "Medium", "Tight"]
SignalBkgr = ["Signal", "Bkgr"]

#Load in all histograms
for n, hn, x in zip(SignalVarNames, SignalVarHistNames, SignalxHistNames):
    SignalVarFile = TFile("/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/Histos/SignalVar_" + n +".root")
    SignalVarHist = []
    SignalVarHist.append(SignalVarFile.Get(hn))
    DrawHist(SignalVarHist, x, ["Measured in Z->ll"],"/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/SignalVar_" + n)
print("weh")
for n, hn, x in zip(BkgrVarNames, BkgrVarHistNames, BkgrxHistNames):
    BkgrVarFile = TFile("/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/Histos/BkgrVar_" + n +".root")
    BkgrVarHist = []
    BkgrVarHist.append(BkgrVarFile.Get(hn))
    DrawHist(BkgrVarHist, x, ["Measured in QCD sample"],"/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/BkgrVar_" + n)
print("test")
for sb in SignalBkgr:
    for discr in discriminatorNames:
        EfficiencyPtHist = []
        EfficiencyEtaHist = []
        print(sb)
        print(discr)
        for WP in WPNames : 
            print(WP)
            print(str(discriminatorNames.index(discr))+str(WPNames.index(WP))+str(SignalBkgr.index(sb)))
            print("Efficiency"+sb+"_Pt_"+discr+"_"+WP+".root")
            EfficiencyPtFile = TFile("/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/Histos/Efficiency"+sb+"_Pt_"+discr+"_"+WP+".root")
            EfficiencyPtHist.append(EfficiencyPtFile.Get("EfficiencyPtNum"+str(discriminatorNames.index(discr))+str(WPNames.index(WP))+str(SignalBkgr.index(sb))))
            EfficiencyEtaFile = TFile("/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/Histos/Efficiency"+sb+"_Eta_"+discr+"_"+WP+".root")
            EfficiencyEtaHist.append(EfficiencyEtaFile.Get("EfficiencyEtaNum"+str(discriminatorNames.index(discr))+str(WPNames.index(WP))+str(SignalBkgr.index(sb))))
            print(EfficiencyPtHist[WPNames.index(WP)].GetBinWidth(1))
        if not discr == "CutBased" :
            print(len(EfficiencyPtHist))
            DrawHist(EfficiencyPtHist, "p_{T} [GeV]", WPNames,  "/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/"+sb+"_"+discr+"AsFuncOfPt")
            DrawHist(EfficiencyEtaHist, "#eta", WPNames,  "/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/"+sb+"_"+discr+"AsFuncOfEta")
        else :     
            DrawHist(EfficiencyPtHist, "p_{T} [GeV]", WPNamesCutBased,  "/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/"+sb+"_"+discr+"AsFuncOfPt")
            DrawHist(EfficiencyEtaHist, "#eta",WPNamesCutBased,  "/user/lwezenbe/private/PhD/Results/TauStudy/ReproducePlots/"+sb+"_"+discr+"AsFuncOfEta")
