import ROOT
from ROOT import TColor, TCanvas, TLegend, gROOT, gStyle, TH1
import CMS_lumi as cl
import tdrstyle as tdr
import numpy as np

def GeneralSettings():
    gROOT.SetBatch(True)
    gStyle.SetOptStat(0)
    tdr.setTDRStyle()
    gStyle.SetPaintTextFormat("4.2f")
    gROOT.ProcessLine( "gErrorIgnoreLevel = 1001;")

def GetStackColor(index):
    if index == 0:      return "#4C5760"
    if index == 1:      return "#93A8AC"
    if index == 2:      return "#D7CEB2"
    if index == 3:      return "#F4FDD9"
    if index == 4:      return "#AA767C"
    if index == 5:      return "#D6A184"

def GetHistColor(index):        
    if index == 0:      return "#000000"
    if index == 1:      return "#000075"
    if index == 2:      return "#800000"
    if index == 3:      return "#f58231"
    if index == 4:      return "#3cb44d"
    if index == 5:      return "#ffe119"

def GetOverallMaximum(hist):
    try:
        currentMax = 0
        for h in hist:
            if h.GetMaximum() > currentMax :    currentMax = h.GetMaximum()
        return currentMax
    except:
        return h.GetMaximum()

def GetOverallMinimum(hist):
    try:
        currentMin = 0
        for h in hist:
            if h.GetMinimum() > currentMin :    currentMin = h.GetMinimum()
        return currentMin
    except:
        return h.GetMinimum()


def plotDataVSMC(DataHist, MCHist, xtitle, legendNames, DataName, destination, outputName):
    Canv = TCanvas("Canv", "Canv", 1000, 1000)
    
    #Set Histogram Styles
    for h in MCHist :
        h.SetFillColor(GetStackColor(MCHist.index(h))) 
        h.SetLineColor(GetStackColor(MCHist.index(h)))
    
    DataHist.SetMarkerColor(ROOT.kBlack)
    DataHist.SetLineColor(ROOT.kBlack)    
   
    #Create Stack (Change with most logical ordering)
    hs = THStack("hs", "hs")
    for h in xrange(len(MCHist)):
        hs.Add(MCHist[h])
    title = " ; ; Events / " +str(MCHist[0].GetBinWidth(1)) + " GeV"
    hs.SetTitle(title)
    hs.GetHistogram().GetXaxis().SetTickLength(0)
    hs.GetHistogram().GetXaxis().SetLabelOffset(0)

    #Create Legend
    legend = TLegend(0.7, .7, .9, .9)
    for h, n in zip(MCHist, legendNames):
        legend.AddEntry(h, n)
    legend.AddEntry(DataHist, DataName)  

    #First pad
    plotpad = TPad("plotpad", "plotpad", 0, .3, 1, 1)
    plotpad.SetBottomMargin(0.025)
    plotpad.Draw()
    plotpad.cd()

    hs.Draw("EHist")
    
    DataHist.Draw("EHist")
    
    legend.Draw()

    #Return to canvas
    MassCanv.cd()

    #Second pad
    ratiopad = TPad("ratiopad", "ratiopad", 0, 0.05, 1, .3)
    ratiopad.SetTopMargin(0.05)
    ratiopad.SetBottomMargin(0.25)
    ratiopad.Draw()
    ratiopad.cd()
    
    #Add all MC samples to use in ratios
    totBkgr = ZmassHistMC[0].Clone("totBkgr")
    for sample in xrange(1, len(MCHist)):
        totBkgr.Add(ZmassHistMC[sample])
    DataOverMC = DataHist.Clone("DataOverMC")
    DataOverMC.Divide(totBkgr)

    #Set Style for bottom plot
    DataOverMC.SetTitle(";" + xtitle + "; Data/MC")
    DataOverMC.GetXaxis().SetTitleSize(.12)
    DataOverMC.GetYaxis().SetTitleSize(.12)
    DataOverMC.GetXaxis().SetLabelSize(.12)
    DataOverMC.GetYaxis().SetLabelSize(.12)
    DataOverMC.Draw("EP")
    
    #Save everything
    MassCanv.SaveAs(destination +"/" + outputName + ".pdf")
    MassCanv.SaveAs(destination +"/" + outputName + ".png")
    MassCanv.SaveAs(destination +"/" + outputName + ".root")

def plotROC(xdata, ydata, xlabel, ylabel, additionalInfo, destination, xerror = None, yerror = None, xlog = False, ylog = False):
    #Create Canvas
    Canv = TCanvas("Canv", "Canv", 1000, 1000)
    
    tdr.setTDRStyle()

    #TGraph and Style
    graph = TGraphErrors(len(xdata), xdata, ydata, xerror, yerror)
    graph.SetTitle(";" + xlabel + ";" + ylabel)
    graph.SetMarkerStyle(.5)
    
    graph.Draw("AP")
    cl.CMS_lumi(Canv, 4, 11)
    
    if xlog :
        Canv.SetLogx()
        graph.GetXaxis().SetRangeUser(0.3*np.min(xdata), 30*np.min(xdata))
    else :
        graph.GetXaxis().SetRangeUser(0.7*np.min(xdata), 1.3*np.min(xdata))
    
    if ylog :
        Canv.SetLogy()
        graph.GetYaxis().SetRangeUser(0.3*np.min(ydata), 30*np.min(ydata))
    else :
        graph.GetYaxis().SetRangeUser(0.7*np.min(ydata), 1.3*np.min(ydata))
   
     #Save
    Canv.SaveAs(destination + ".pdf")    
    Canv.SaveAs(destination + ".png")    
    Canv.SaveAs(destination + ".root")    

def DrawHist(hist, xlabel, legendNames, destination, ylog = False):
    GeneralSettings()
    #Create Canvas
    print("wat")
#    Canv = TCanvas("Canv", "Canv", 1000, 1000)
    print("halp")

    tdr.setTDRStyle()

    print(len(hist))
    print(hist[0].GetBinWidth(0))

   
    print("secondtest") 
    #Set Histogram Styles
    for h in hist:
       # h.SetLineColor(TColor.GetColor(GetHistColor(hist.index(h))))
        print("thirdtest")         
    #title = " ;" +xlabel+ " ; Events / " +str(hist[0].GetBinWidth(1)) + " GeV"
    #hist[0].SetTitle(title)
    
#    OverallMax = GetOverallMaximum(hist)
#    OverallMin = GetOverallMinimum(hist)

#    if ylog :
#        Canv.SetLogy()
#        hist[0].GetYaxis().SetRangeUser(0.3*OverallMin, 30*OverallMax)
#    else :
#        hist[0].GetYaxis().SetRangeUser(0.7*OverallMin, 1.3*OverallMax)

    #Start Drawing
#    for h in hist:
#        if(hist.index(h) == 0) :
#            h.Draw("HIST")
#        else:
#            h.Draw("EHIST")
    #Create Legend
    if legendNames :
        legend = TLegend(0.7, .7, .9, .9)
        for h, n in zip(hist, legendNames):
            legend.AddEntry(h, n)
        legend.SetFillStyle(0)
        legend.SetBorderSize(0)
        legend.Draw()
    
    #CMS lumi
#    cl.CMS_lumi(Canv, 4, 11)

    #Save
#    Canv.SaveAs(destination + ".pdf")    
#    Canv.SaveAs(destination + ".png")    
#    Canv.SaveAs(destination + ".root")
